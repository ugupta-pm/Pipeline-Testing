from test_version import func

def hello():
    output = func()
    return output
